# Yasin TV Launcher (Актобе)

Минималистичный лаунчер для YASIN Smart TV на Android в стиле glassmorphism.

## Возможности
- Часы, дата и текущая погода для Актобе (без почасового прогноза).
- Живые обои Yasin с плавной анимацией; запуск выбора обоев кнопкой «ОБОИ».
- Быстрый переход в системные настройки ТВ.
- Автоматический список установленных Android/TV-приложений.
- Навигация и фокус с помощью пульта.

## Сборка APK через GitHub Actions
1. Создай пустой репозиторий GitHub.
2. Загрузи в него содержимое этой папки, сохранив структуру каталогов.
3. Открой вкладку **Actions** и запусти workflow **Build Yasin TV Launcher APK** (Run workflow).
4. После успешной сборки открой завершённый запуск workflow и скачай artifact **YasinTVLauncher-debug**.
5. Внутри будет `app-debug.apk`. Установить можно с флешки или командой `adb install -r app-debug.apk`.

## Параметры
- Application ID: `com.aktobe.yasinlauncher`
- minSdk: 24 (Android 7.0)
- compileSdk / targetSdk: 34
- Версия: 1.0

Для локальной сборки требуется JDK 17, Android SDK 34 и Gradle 8.2.
