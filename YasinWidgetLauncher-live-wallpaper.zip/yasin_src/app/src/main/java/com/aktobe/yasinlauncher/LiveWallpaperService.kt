package com.aktobe.yasinlauncher

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.sin

class LiveWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = AuroraEngine()

    private inner class AuroraEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var visible = false
        private var startedAt = System.currentTimeMillis()
        private val frame = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 40L)
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(frame)
            if (visible) handler.post(frame)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(frame)
            super.onDestroy()
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val w = canvas.width.toFloat()
                    val h = canvas.height.toFloat()
                    val t = (System.currentTimeMillis() - startedAt) / 1000.0
                    canvas.drawColor(Color.rgb(5, 12, 30))
                    drawGlow(canvas, w * (0.25f + 0.10f * sin(t * 0.18).toFloat()), h * 0.42f, w * 0.78f, 0x553B82F6, 0x003B82F6)
                    drawGlow(canvas, w * (0.72f + 0.12f * sin(t * 0.13 + 2.0).toFloat()), h * 0.62f, w * 0.72f, 0x554F46E5, 0x004F46E5)
                    drawGlow(canvas, w * (0.48f + 0.08f * sin(t * 0.10 + 4.0).toFloat()), h * 0.18f, w * 0.55f, 0x3342D6C5, 0x0042D6C5)
                }
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun drawGlow(canvas: Canvas, x: Float, y: Float, radius: Float, center: Int, edge: Int) {
            paint.shader = RadialGradient(x, y, radius, center, edge, Shader.TileMode.CLAMP)
            canvas.drawCircle(x, y, radius, paint)
            paint.shader = null
        }
    }
}
