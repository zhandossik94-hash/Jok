package com.aktobe.yasinlauncher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AktobeWeather(
    val currentTemp: Int,
    val windSpeed: Int,
    val conditionText: String
)

object WeatherRepository {
    // Текущая погода в Актобе; почасовой прогноз отключён.
    private const val API_URL =
        "https://api.open-meteo.com/v1/forecast?latitude=50.2839&longitude=57.1670&current=temperature_2m,weather_code,wind_speed_10m&timezone=Asia%2FAqtobe"

    suspend fun fetchWeather(): AktobeWeather? = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(API_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.requestMethod = "GET"
            if (conn.responseCode != 200) return@withContext null
            val response = conn.inputStream.bufferedReader().use { it.readText() }
            val current = JSONObject(response).getJSONObject("current")
            AktobeWeather(
                currentTemp = Math.round(current.getDouble("temperature_2m")).toInt(),
                windSpeed = Math.round(current.getDouble("wind_speed_10m")).toInt(),
                conditionText = mapWeatherCode(current.getInt("weather_code"))
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun mapWeatherCode(code: Int): String = when (code) {
        0 -> "Ясно"
        1, 2 -> "Малооблачно"
        3 -> "Пасмурно"
        45, 48 -> "Туман"
        51, 53, 55, 61, 63, 65, 80, 81, 82 -> "Дождь"
        56, 57, 66, 67 -> "Ледяной дождь"
        71, 73, 75, 77, 85, 86 -> "Снег"
        95, 96, 99 -> "Гроза"
        else -> "Облачно"
    }
}
