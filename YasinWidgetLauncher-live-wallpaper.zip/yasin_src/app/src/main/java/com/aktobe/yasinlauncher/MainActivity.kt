package com.aktobe.yasinlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var tvClock: TextView
    private lateinit var tvCurrentTemp: TextView
    private lateinit var tvDateCity: TextView
    private lateinit var tvWeatherSummary: TextView
    private lateinit var rvApps: RecyclerView

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateClockAndDate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvClock = findViewById(R.id.tvClock)
        tvCurrentTemp = findViewById(R.id.tvCurrentTemp)
        tvDateCity = findViewById(R.id.tvDateCity)
        tvWeatherSummary = findViewById(R.id.tvWeatherSummary)
        rvApps = findViewById(R.id.rvApps)

        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
        findViewById<TextView>(R.id.btnWallpapers).setOnClickListener {
            val intent = Intent(android.app.WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(android.app.WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    android.content.ComponentName(this@MainActivity, LiveWallpaperService::class.java))
            }
            try {
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(android.app.WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            }
        }

        updateClockAndDate()
        setupAppsDock()
        startWeatherLoop()
    }

    override fun onResume() {
        super.onResume()
        updateClockAndDate()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        registerReceiver(timeReceiver, filter)
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(timeReceiver)
        } catch (_: Exception) {
        }
    }

    private fun updateClockAndDate() {
        val now = Date()
        val clockFormat = SimpleDateFormat("HH:mm", Locale("ru"))
        val dateFormat = SimpleDateFormat("EEEE, d MMMM", Locale("ru"))

        tvClock.text = clockFormat.format(now)
        val dateStr = dateFormat.format(now).replaceFirstChar { it.uppercase() }
        tvDateCity.text = "$dateStr • Актюбинск"
    }

    private fun setupAppsDock() {
        val pm = packageManager
        val appsMap = LinkedHashMap<String, AppModel>()

        // Собираем как TV (Leanback), так и обычные Android приложения
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        )

        for (intent in intents) {
            val resolved = pm.queryIntentActivities(intent, 0)
            for (info in resolved) {
                val pkg = info.activityInfo.packageName
                if (pkg == packageName || appsMap.containsKey(pkg)) continue
                val label = info.loadLabel(pm).toString()
                val icon = info.loadBanner(pm) ?: info.loadIcon(pm)
                appsMap[pkg] = AppModel(label, pkg, icon)
            }
        }

        // Приоритет популярных видео-приложений в начале списка
        val priorityPackages = listOf(
            "com.google.android.youtube.tv",
            "com.liskovsoft.smarttubetv.beta",
            "com.liskovsoft.smarttubetv",
            "ru.kinopoisk.tv",
            "ru.kinopoisk",
            "com.netflix.ninja",
            "org.xbmc.kodi",
            "ru.rutube.app"
        )

        val sortedList = appsMap.values.sortedWith(compareBy(
            { app ->
                val idx = priorityPackages.indexOf(app.packageName)
                if (idx == -1) 999 else idx
            },
            { it.label.lowercase() }
        ))

        rvApps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvApps.adapter = AppsAdapter(sortedList) { app ->
            val launchIntent = pm.getLeanbackLaunchIntentForPackage(app.packageName)
                ?: pm.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null) {
                startActivity(launchIntent)
            }
        }

        // Фокус сразу на первую карточку для удобного управления пультом
        rvApps.post {
            rvApps.getChildAt(0)?.requestFocus()
        }
    }

    private fun startWeatherLoop() {
        lifecycleScope.launch {
            while (isActive) {
                val weather = WeatherRepository.fetchWeather()
                if (weather != null) {
                    val sign = if (weather.currentTemp > 0) "+" else ""
                    tvCurrentTemp.text = "$sign${weather.currentTemp}°"
                    tvWeatherSummary.text = "${weather.conditionText} • Ветер ${weather.windSpeed} м/с"
                } else {
                    tvWeatherSummary.text = "Нет связи с метеосервером"
                }
                // Обновление каждые 30 минут
                delay(30 * 60 * 1000L)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Игнорируем кнопку "Назад" на главном экране лаунчера
    }
}
