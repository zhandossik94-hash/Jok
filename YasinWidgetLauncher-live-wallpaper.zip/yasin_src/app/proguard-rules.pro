# Project-specific ProGuard/R8 rules.
# Keep empty for the initial debug build; add rules only when required.
