package com.aktobe.yasinlauncher

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class WeatherInfo(
    val temp: String,
    val condition: String,
    val city: String
)

class WeatherRepository {
    private val handler = Handler(Looper.getMainLooper())

    fun fetchWeather(callback: (WeatherInfo?) -> Unit) {
        Thread {
            try {
                val urlStr = "https://api.open-meteo.com/v1/forecast?latitude=50.2839&longitude=57.167&current=temperature_2m,weather_code"
                val url = URL(urlStr)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(response)
                    val current = json.getJSONObject("current")
                    val tempValue = current.getDouble("temperature_2m")
                    val weatherCode = current.getInt("weather_code")
                    val conditionStr = getWeatherDescription(weatherCode)

                    val info = WeatherInfo(
                        temp = "${tempValue.toInt()}°C",
                        condition = conditionStr,
                        city = "Актюбинск"
                    )
                    handler.post { callback(info) }
                } else {
                    handler.post { callback(null) }
                }
            } catch (e: Exception) {
                handler.post { callback(null) }
            }
        }.start()
    }

    private fun getWeatherDescription(code: Int): String {
        return when (code) {
            0 -> "Ясно"
            1, 2, 3 -> "Облачно"
            45, 48 -> "Туман"
            51, 53, 55, 56, 57 -> "Морось"
            61, 63, 65, 66, 67 -> "Дождь"
            71, 73, 75, 77 -> "Снег"
            80, 81, 82 -> "Ливень"
            95, 96, 99 -> "Гроза"
            else -> "Пасмурно"
        }
    }
}
