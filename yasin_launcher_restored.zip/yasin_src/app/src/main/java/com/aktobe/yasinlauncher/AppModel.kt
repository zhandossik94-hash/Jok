package com.aktobe.yasinlauncher

data class AppModel(
    val name: String,
    val packageName: String,
    val activityName: String,
    val icon: android.graphics.drawable.Drawable?
)
