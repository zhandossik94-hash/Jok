package com.aktobe.yasinlauncher

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.aktobe.yasinlauncher.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var appsAdapter: AppsAdapter
    private val weatherRepo = WeatherRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClockAndDate()
        setupWeather()
        setupAppsGrid()
        setupListeners()
    }

    private fun setupClockAndDate() {
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEEE, d MMMM", Locale("ru"))
        
        binding.txtTime.text = timeFormat.format(Date())
        binding.txtDate.text = dateFormat.format(Date())

        binding.root.postDelayed(object : Runnable {
            override fun run() {
                binding.txtTime.text = timeFormat.format(Date())
                binding.txtDate.text = dateFormat.format(Date())
                binding.root.postDelayed(this, 10000)
            }
        }, 10000)
    }

    private fun setupWeather() {
        weatherRepo.fetchWeather { info ->
            if (info != null) {
                binding.txtWeatherTemp.text = info.temp
                binding.txtWeatherCondition.text = "${info.city}, ${info.condition}"
            } else {
                binding.txtWeatherTemp.text = "--°C"
                binding.txtWeatherCondition.text = "Актюбинск"
            }
        }
    }

    private fun setupAppsGrid() {
        val apps = loadInstalledApps()
        appsAdapter = AppsAdapter(apps) { app ->
            launchApp(app)
        }
        binding.recyclerViewApps.apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = appsAdapter
        }
    }

    private fun setupListeners() {
        binding.btnSettings.setOnClickListener {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadInstalledApps(): List<AppModel> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        return resolveInfos.map { resolveInfo ->
            val activity = resolveInfo.activityInfo
            AppModel(
                name = resolveInfo.loadLabel(pm).toString(),
                packageName = activity.packageName,
                activityName = activity.name,
                icon = resolveInfo.loadIcon(pm)
            )
        }.sortedBy { it.name }
    }

    private fun launchApp(app: AppModel) {
        val intent = Intent().apply {
            component = ComponentName(app.packageName, app.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить ${app.name}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        // Do nothing on home screen
    }
}
